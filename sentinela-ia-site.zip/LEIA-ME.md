# Sentinela IA — como colocar o site no ar

Este pacote é a Sentinela como **site próprio**: abre em qualquer navegador, conversa por voz (inclusive no iPhone, pelo Safari) e usa a IA do Claude por meio de uma chave **sua**, guardada no servidor.

## Antes de começar: o nome do site

`sentinela.ia` **não existe**: `.ia` não é uma terminação de domínio válida. Opções reais:

| Domínio | Onde registrar | Observação |
|---|---|---|
| `sentinelaia.com.br` | registro.br | precisa de CPF ou CNPJ; cerca de R$ 40 por ano |
| `sentinela-ia.com` | Registro.br não vende `.com`; use um registrador como o da Vercel | |
| `sentinela.ai` | registradores internacionais | `.ai` é bem mais caro |

Confira se o nome está livre antes de decidir. Os arquivos já vêm com `sentinelaia.com.br`; se escolher outro, troque esse endereço em `index.html`, `robots.txt` e `sitemap.xml`.

## Passo a passo (no computador)

1. **Chave da IA.** Crie uma conta em console.anthropic.com, adicione créditos e gere uma *API key*. No mesmo painel, defina um **limite de gasto mensal**: o site é público e cada visita usa a sua chave.
2. **Node.js.** Instale a versão LTS em nodejs.org.
3. **Descompacte** esta pasta e abra o Terminal (Mac) ou o Prompt de Comando (Windows) dentro dela.
4. **Teste no seu computador (opcional):**
   ```
   npm install
   ```
   Depois, no Mac:
   ```
   ANTHROPIC_API_KEY=sua-chave node dev-server.js
   ```
   No Windows (Prompt de Comando):
   ```
   set ANTHROPIC_API_KEY=sua-chave
   node dev-server.js
   ```
   Abra http://localhost:3000.
5. **Publique na Vercel** (gratuito, não precisa de GitHub):
   ```
   npx vercel
   ```
   Siga as perguntas (login por e-mail, aceite os padrões). Depois:
   ```
   npx vercel env add ANTHROPIC_API_KEY
   npx vercel --prod
   ```
   O site ganha um endereço como `sentinela-ia.vercel.app`.
6. **Seu domínio.** No painel da Vercel: *Settings › Domains › Add* e digite o domínio. A Vercel mostra os registros de DNS que você deve copiar no painel do registrador (no Registro.br, em *DNS*).

## Aparecer no Google

O Google não hospeda sites: ele encontra e lista o seu. Para acelerar:

1. Entre em search.google.com/search-console e adicione o domínio.
2. Confirme que o site é seu com o registro TXT que o Google mostrar (vai no DNS, como no passo 6).
3. Em *Sitemaps*, envie `sitemap.xml`.

Em alguns dias o site começa a aparecer nas buscas por "Sentinela IA". Aparecer no topo depende de outros sites citarem o seu.

## Quanto custa

- **Vercel:** grátis no plano Hobby, para uso pessoal e não comercial.
- **Domínio:** a partir de cerca de R$ 40 por ano (`.com.br`).
- **IA, por estimativa:** cerca de US$ 0,10 a 0,20 por pesquisa de empresa (inclui busca na web) e menos de 1 centavo por pergunta. Acompanhe o gasto no painel da Anthropic.

## Como funciona

- `index.html`: o site (esfera, terminal, voz e microfone do navegador).
- `api/empresa.js`: pesquisa falhas corrigidas por hackers éticos, com busca na web.
- `api/conversa.js`: responde perguntas, com memória da conversa.
- `api/_lib.js`: regras da IA (só dados públicos, nada de ataques) e limite de uso por visitante.

Para trocar o modelo de IA, crie a variável `ANTHROPIC_MODEL` na Vercel. O padrão é `claude-sonnet-4-6`.

## Voz e microfone

- Toque na **esfera**: ela cumprimenta e começa a ouvir. Depois, chame por "Sentinela".
- O navegador pede permissão para o microfone na primeira vez.
- Funciona no Chrome e no Edge (computador e Android) e no Safari do iPhone. O Firefox não tem reconhecimento de voz.
- O site precisa estar em **https** para o microfone funcionar; a Vercel já faz isso.
